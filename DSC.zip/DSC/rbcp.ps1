﻿$share1 = '\\primarystorageftp001.file.core.windows.net\ftpshareprimary\ftpshare'
$share2 = '\\primarystorageftp002.file.core.windows.net\ftpshareprimary\ftpshare'
$StorageKey1='sWDi//0p1f3OZm7PJo9V3f7XkdVGggEBQS32ACFvZcwf+7ejBnV8fFxNo3RFuPZ6m7BIA0iBTwSphmdt1zrbcA=='
$shareName1='ftpshareprimary'
$StorageName2='primarystorageftp002'
$StorageKey2='a0R4EfwiE9OhQgjxkrPhmgZBw0Zb0ysZhjoHa7hffpoan8l8rINxSznX1f74/q6rYjDVVsEdMEN9RTQoS7ekog'


#Check if log folder exists#
$ExistLog=Test-Path C:\support
if ($ExistLog -eq $false)
{
mkdir c:\support
}

cd C:\Windows\System32\inetsrv
$stg= .\appcmd.exe list vdir CometFTP/$stg1=$stg.split('(')[1].split(')')[0]$stgf=$stg1.split(':')[1]$stgf

$ExistShare1= Test-Path $share1
if ($ExistShare1 -eq $false)
{
    try
    {
    Start-Process "C:\Deploy\mountprim.bat"
    }
    catch
    {

    }
}
$ExistShare2= Test-Path $share2
if ($ExistShare2 -eq $false)
{
    try
    {
    Start-Process "C:\Deploy\mountsec.bat"
    }
    catch
    {

    }
}

if ($ExistShare1 -eq $true -and $ExistShare2 -eq $true)
{
Robocopy.exe $share1 $share2 /E  /COPY:DAT /R:3 /W:5 #/LOG+:C:\Support\syncfiles1.log
Robocopy.exe $share2 $share1 /E  /COPY:DAT /R:3 /W:5 #/LOG+:C:\Support\syncfiles2.log
}
else
{ 
    if ($ExistShare1 -eq $false -and $stgf -eq $share1)
    {
    Write-Host "vai correr script para configurar FTP para share 2"
    C:\Deploy\confFTPSecSs.bat
    } else{
            if ($ExistShare2 -eq $false -and $stgf -eq $share2)
            {
            Write-Host "vai correr script para configurar FTP para share 1"
            C:\Deploy\confFTPprimPs.bat
            }
            }
}




